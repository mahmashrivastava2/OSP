<html>
    <head>
        
        <title>Create a department</title>
    
    </head>
    <body>
        <h1 align="center">Create department</h1>
        <form action="adddepINS.php" method="post">
            <table>
                <tr>
                    <td>Name of the department : </td>
                    <td><input type="text" name=depname></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Create"></td>
                </tr>
                <tr>
                    <td><a href="department.php">Back</a></td>
                </tr>
            </table>
        </form>
    </body>
</html>
