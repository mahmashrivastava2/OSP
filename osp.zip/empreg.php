<?php
    $connection=mysqli_connect('localhost','root','aressam1999');
    mysqli_select_db($connection,"bugtracker") or die("2");
    $q="SELECT * FROM department";
    $result=mysqli_query($connection,$q) or die(mysqli_error);
?>
<html>
    <head>
        <title>Employee registration</title>
        <link href="csspage.css" rel="StyleSheet" type="text/css">
    </head>    
    <body>
        
        <h1 align="center">Register an employee</h1>
        <form action="empregINS.php" method="post">
        <table>
            <tr>
                <td>Name</td>
                <td><input type="text" name=name></td>
            </tr>
            <tr>
                <td>Gender</td>
                <td>
                    <input type="radio" name=gen value="m" checked>Male
                    <input type="radio" name=gen value="f">Female
                </td>
            </tr>
            <tr>
                <td>Birth Date</td>
                <td><input type="date" name=dob></td>
            </tr>
            <tr>
                <td>Department</td>
                <td>
                    
                    <select name=department>
                        <option value="sel">sel</option>
                    <?php
			while($row=mysqli_fetch_array($result))
                    {?>
                       
                            <option value="<?php $row['depid'] ?>"><?php echo $row['depname'] ?></option>
                    <?php } ?>
                    </select>
                    
                </td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name=email></td>
            </tr>
            <tr>
                <td>Mobile</td>
                <td><input type="text" name=mobile></td>
            </tr>
            <tr>
                <td>Is active?</td>
                <td>
                    <input type="radio" name=status value="y" checked>YES
                    <input type="radio" name=status value="n">NO                
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="enroll"></td>
            </tr>   
            <tr>
                <td><a href="manageemployees.php">Back</a></td>
            </tr>
        </table>
        </form>
        </body>
</html>
<?php
mysqli_close($connection);
?>
