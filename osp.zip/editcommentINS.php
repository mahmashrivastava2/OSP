<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <?php
            $comment=$_POST['comment'];
            $active=$_POST['active'];
            $commentid=$_POST['commentid'];
            $rby=$_POST['rby'];

            $con=mysqli_connect("localhost","root","aressam1999");
            $q="UPDATE comments SET comment='",$comment,"',active='",$active,"' WHERE commentid=",$commentid;
            mysqli_query($con, $q);
            header('Location: view.jsp?id=',$rby);
        ?>
    </body>
</html>
