<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <?php
            $comment=$_POST['comment'];
            $rby=$_POST['rby'];
            $bugid = $_POST['bugid'];
            $con=mysqli_connect("localhost","root","aressam1999");
            $q="INSERT INTO comments(commentid,bugid,comment,rby,active) VALUE(0,'".$bugid."','".$comment."','".$rby."','y')";
            mysqli_query($con, $q);

            $q2="SELECT * FROM bugs WHERE bugid='".$bugid."'"; //Check datatype of $bugid
            $res = mysqli_query($con, $q2);
            if(mysqli_num_rows($q2) > 0){
            header('Location: mybugs.jsp?id=',$rby);
            }
        ?>
    </body>
</html>
