<html>
    <head>
        <title>Bugs i reported</title>
        <?php//<link href="csspage.css" rel="StyleSheet" type="text/css">?>
    </head>
    <body/>
        <?php
            $id = $_POST[''];
            $con = mysqli_connect("localhost","root","aressam1999");
            $q="SELECT * FROM bugs WHERE assign='".$id."'"; //Check datatype of $id
            $res=mysqli_query($con, $q);

        ?>
        <h1 align="center">Bugs that were reported to you</h1>
        <table class="table2">
            <tr>
                <td>Bug title</td>
                <td>Bug description</td>
                <td>Solve</td>
            </tr>
            <tr><td><br></td></tr>
            <?php
            while($row = mysqli_fetch_array($res))
            {
            ?>
            <tr>
                <td><?=$row['bug']?></td>
                <td><?=$row['bugdes']?></td>
                <td><a href="solvebug.jsp?id=<?=$row['bugid']?>,id2=<?=$row['assign']?>">Solve</a></td>

            </tr>
            <?php
                        }
            ?>
            <tr>
                <td><a href="emphome.jsp">Back</a></td>
            </tr>
        </table>
    </body>
</html>
