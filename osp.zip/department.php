<html>
    <head>
        <title>Manage department</title>

       <link href="csspage.css" rel="StyleSheet" type="text/css">//

    </head>
    <body>
        <h1 align="center">Manage department</h1>
        <table class="table2">
            <tr>
                <td><a href="viewdep.php">View and edit existing departments</a></td>
            </tr>
            <tr>
                <td><a href="adddep.php">Create departments</a></td>
            </tr>
            <tr>
                <td><a href="deldep.php">Dissolve departments</a></td>
            </tr>
            <tr>
                <td><a href="adminhome.php">Home</a></td>
            </tr>
        </table>
    </body>
</html>
