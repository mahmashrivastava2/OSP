<html>
    <head>
        <title>Report a bug</title>
        <?php<link href="csspage.css" rel="StyleSheet" type="text/css">?>
    </head>
    <body>
        <?php
            $id = $_POST[''] //Get name from previous page
            $con=mysqli_connect("localhost","root","aressam1999");
            $q="SELECT * FROM comments WHERE commentid=",$id;
            $res=mysqli_query($con, $q);

            //Statement obj4=obj1.createStatement();
            //String q2="SELECT * FROM empreg";
            //ResultSet obj5=obj4.executeQuery(q2);

            //Statement obj6=obj1.createStatement();
            //String q3="SELECT * FROM empreg";
            //ResultSet obj7=obj6.executeQuery(q3);

            //Statement obj8=obj1.createStatement();
            //String q4="SELECT * FROM bugs WHERE bugid='"+request.getParameter("id")+"'";
            //ResultSet obj9=obj8.executeQuery(q4);
            while($row = mysqli_fetch_array($res))
            {
        ?>
        <h1 align="center">Edit this comment : </h1>
        <form action="editcommentINS.jsp" method="post">
            <table class="table2">
                <tr>
                    <td>Do you want to revoke this comment?</td>
                    <td> <input type="radio" name=active value="n">Yes<br>
                         <input type="radio" name=active value="y" checked>No
                    </td>
                </tr>
                <tr><td><br></td>
                    <td><br></td></tr>
                <tr>
                    <td>Comment : </td>
                    <td><textarea name=comment><?=$row['comment']?></textarea></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="hidden" name=rby value="<?=$row['rby']?>">
                        <input type="hidden" name=commentid value="<?=$row['commentid']?>">
                        <input type="submit" value="Change"></td>
                </tr>
                <tr>
                    <td><a href="view.jsp?id=<?=$row['rby']?>">Back</a></td>
                    <td></td>
                </tr>
            </table>
        </form>
    <?php}?>
    </body>
</html>
