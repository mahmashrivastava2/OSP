<html>
    <head>
        <title>Employee home</title>
        <?php//<link href="csspage.css" rel="StyleSheet" type="text/css">?>
    </head>
    <body>
        <?php
            $user = $_SESSION['user'] //Get name from previous page
            $con=mysqli_connect("localhost","root","aressam1999");
            $q="SELECT * FROM empreg WHERE mobile='",$user,"'";
            $res=mysqli_query($con, $q);
            while($row = mysqli_fetch_array($res))
            {
            ?>
        <h1>User : <?=$row'[name']?></h1>
        <table class="table1">
            <tr>
                <td><a href="requestproject.jsp?id=<?=$row['eid']?>">Request regarding projects</a></td>
            </tr>
            <tr>
                <td><a href="requestjob.jsp?id=<?=$row['eid']?>">Request regarding job</a></td>
            </tr>
            <tr>
                <td><a href="requestquery.jsp?id=<?=$row['eid']?>">Query regarding project assigned</a></td>
            </tr>
            <tr>
                <td><a href="tech.jsp?id=<?=$row['eid']?>">Technical complaint</a></td>
            </tr>
            <tr>
                <td><a href="emphome.jsp">Back</a></td>
            </tr>
        </table>
        <?php
            }
        ?>
    </body>
</html>
