
        <?php
            session_destroy();
 	    header('Location: adminlogin.php');
            ?>
