<!DOCTYPE html>
<html>
    <head>
        <title>Admin login</title>  
        <link href="csspage.css" rel="StyleSheet" type="text/css">
    </head>
    <body>
        <h1 align="center">Admin login</h1>
        <form action="adminloginINS.php" method="post">
            <table class="table2">
                <tr>
                    <td>Admin user name : </td>
                    <td><input type="text" name=admin></td>
                </tr>
                <tr>
                    <td>Enter password : </td>
                    <td><input type="password" name=pass></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Login"></td>
                </tr>
            </table>
        </form>
        <br>
        <br>
        
    </body>
</html>
