<?php
    $name=$_POST['name'];
    $gen=$_POST['gen'];
    $department=$_POST['department'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $status=$_POST['status'];
    $dob=$_POST['dob'];
    $connection=mysqli_connect('localhost','root','aressam1999');
    mysqli_select_db($connection,"bugtracker") or die("2");
    //$q="INSERT INTO empreg(eid,name,gen,dob,department,email,mobile,status,username,password) VALUES(0,'".$name."','".$gen."','".$dob."', $department,'".$email."','".$mobile."','".$status."','".$email."','".$mobile."')";
    
    $q="INSERT INTO empreg(eid,name,gen,dob,department,email,mobile,status,username,password) VALUES(0,'".$name."','".$gen."','".$dob."','".$department."','".$email."','".$mobile."','".$status."','".$email."','".$mobile."')";
echo "OK";
    mysqli_query($connection,$q) or die(mysqli_error);
    mysqli_close($connection);
    header('Location: empreg.php');
?>
