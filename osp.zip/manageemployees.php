<html>
    <head>
        <title>Manage Employees</title>
        <link href="csspage.css" rel="StyleSheet" type="text/css">
    </head>
    <body>
        <h1 align="center">Manage employees</h1>
        <table class="table2">
            <tr>
                <td><a href="empreg.php">Enroll new employee</a></td>
            </tr>
            <tr>
                <td><a href="viewemp.php">View commissioned employees</a></td>
            </tr>
            <tr>
                <td><a href="viewemp2.php">View de-commissioned employees</a></td>
            </tr>
            <tr>
                <td><a href="adminhome.php">Back</a></td>
            </tr>
        </table>
    </body>
</html>
