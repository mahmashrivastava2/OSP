<html>
    <head>
        <title>Project</title>
        
		<link href="csspage.css" rel="StyleSheet" type="text/css">
		
    </head>
    <body>
        <h1 align="center">Manage Projects</h1>
        <table class="table2">
            <tr>
                <td><a href="viewproject.php">View and edit pending projects</a></td>
            </tr>
            <tr>
                <td><a href="viewcproject.php">View completed projects</a></td>
            </tr>
            <tr>
                <td><a href="addproject.php">Add new project</a></td>
            </tr>
            <tr>
                <td><a href="adminhome.php">Back</a></td>
            </tr>
        </table>
    </body>
</html>
